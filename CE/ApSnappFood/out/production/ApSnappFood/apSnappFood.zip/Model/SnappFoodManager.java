package Model;

public class SnappFoodManager extends User{
    public SnappFoodManager(String username, String password) {
        super(username, password);
    }
}
